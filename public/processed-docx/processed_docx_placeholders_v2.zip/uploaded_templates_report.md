# Báo cáo mẫu đã tải lên

## DUONG HIEN VANG_DM ho so vay von.docx
- Loại: docx | size: 17876 | lỗi: 
- Gợi ý placeholder:
  - `Dương Hiển Vang` → `{cn_ten_khach_hang}`
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `2001-235488601` → `{cn_ma_khach_hang}`
  - `2001-LAV-202401047` → `{cn_so_hop_dong_tin_dung}`
- HĐ thấy: 2001-LAV-202401047, 2001-LCA-2024007153, 2001-LCL-20240066015

## DUONG HIEN VANG_HSVV_1.2 PA SDV nhu cau doi song co TSB_.docx
- Loại: docx | size: 78351 | lỗi: 
- Gợi ý placeholder:
  - `DƯƠNG HIỂN VANG` → `{cn_ten_khach_hang_in_hoa}`
  - `048077005294` → `{cn_so_cccd}`
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `Hồ Trần Như Quỳnh` → `{cn_ten_vo_chong}`
  - `048180003885` → `{cn_cccd_vo_chong}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`
  - `Phòng giao dịch 2/9` → `{cn_phong_giao_dich}`
- CCCD thấy: 048077005294, 048180003885

## DUONG HIEN VANG_HSVV_24. MS 07. DXGN-CN BC DXGN kiem Giay nhan no 2023.docx
- Loại: docx | size: 101344 | lỗi: 
- Gợi ý placeholder:
  - `Dương Hiển Vang` → `{cn_ten_khach_hang}`
  - `048077005294` → `{cn_so_cccd}`
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `2001-235488601` → `{cn_ma_khach_hang}`
  - `Hồ Trần Như Quỳnh` → `{cn_ten_vo_chong}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`
  - `Phòng giao dịch 2/9` → `{cn_phong_giao_dich}`
- CCCD thấy: 048077005294
- HĐ thấy: 2001-LAV-2024................

## DUONG HIEN VANG_HSVV_26. MS 09.GXN-CN vay nhu cau doi song co huong luong.docx
- Loại: docx | size: 87697 | lỗi: 
- Gợi ý placeholder:
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `Hồ Trần Như Quỳnh` → `{cn_ten_vo_chong}`
  - `048180003885` → `{cn_cccd_vo_chong}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`

## DUONG HIEN VANG_HSVV_28. MS 11A.BBKT-CN BBKT tinh hinh su dung von vay tai Agribank noi cho vay.docx
- Loại: docx | size: 30179 | lỗi: 
- Gợi ý placeholder:
  - `Dương Hiển Vang` → `{cn_ten_khach_hang}`
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `2001-LAV-202401047` → `{cn_so_hop_dong_tin_dung}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`
- HĐ thấy: 2001-LAV-202401047, 2001-LDS-202402711

## DUONG HIEN VANG_HSVV_31. MS 12.BCTN-CN BC tinh hinh thu nhap.docx
- Loại: docx | size: 23337 | lỗi: 
- Gợi ý placeholder:
  - `Dương Hiển Vang` → `{cn_ten_khach_hang}`
  - `DƯƠNG HIỂN VANG` → `{cn_ten_khach_hang_in_hoa}`
  - `048077005294` → `{cn_so_cccd}`
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `Hồ Trần Như Quỳnh` → `{cn_ten_vo_chong}`
  - `048180003885` → `{cn_cccd_vo_chong}`
- CCCD thấy: 048077005294, 048180003885

## DUONG HIEN VANG_HSVV_7. MS 02A.BC_X-CN BCDXCV CN co TSBD.docx
- Loại: docx | size: 83629 | lỗi: 
- Gợi ý placeholder:
  - `Dương Hiển Vang` → `{cn_ten_khach_hang}`
  - `DƯƠNG HIỂN VANG` → `{cn_ten_khach_hang_in_hoa}`
  - `048077005294` → `{cn_so_cccd}`
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `Hồ Trần Như Quỳnh` → `{cn_ten_vo_chong}`
  - `048180003885` → `{cn_cccd_vo_chong}`
  - `24/07/2024` → `{cn_ngay_bao_cao}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`
  - `Phòng giao dịch 2/9` → `{cn_phong_giao_dich}`
- CCCD thấy: 048077005294, 048180003885

## DUONG HIEN VANG_HSVV_Bang ke nguoi co lien quan.docx
- Loại: zip-not-word | size: 92160 | lỗi: Không có word/document.xml

## DUONG HIEN VANG_HSVV_Giay muon tien.docx
- Loại: zip-not-word | size: 31232 | lỗi: Không có word/document.xml

## DUONG HIEN VANG_HSVV_Mau 06E - H_TD cho vay uu dai.docx
- Loại: zip-not-word | size: 142848 | lỗi: Không có word/document.xml

## DUONG HIEN VANG_HSVV_MauDangKyTheoQD711.docx
- Loại: zip-not-word | size: 308224 | lỗi: Không có word/document.xml

## DUONG HIEN VANG_HSVV_Ph_ l_c nh_n n_ 1 l_n.docx
- Loại: docx | size: 20447 | lỗi: 
- Gợi ý placeholder:
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`
  - `Phòng giao dịch 2/9` → `{cn_phong_giao_dich}`
- CCCD thấy: 033065010986
- HĐ thấy: 2001-LAV-2024, 2001-LAV-2024...

## DUONG HIEN VANG_HSVV_SMS no vay.docx
- Loại: zip-not-word | size: 62464 | lỗi: Không có word/document.xml

## DUONG HIEN VANG_HSVV___ MS 02A.BC_X-CN BCDXCV CN co TSBD.docx
- Loại: not-docx | size: 162 | lỗi: File is not a zip file

## DUONG HIEN VANG_HSVV___2 PA SDV nhu cau doi song co TSB_.docx
- Loại: not-docx | size: 162 | lỗi: File is not a zip file

## DUONG HIEN VANG_TAI SAN 2929_DANH MUC HSTS.docx
- Loại: zip-not-word | size: 51200 | lỗi: Không có word/document.xml

## DUONG HIEN VANG_TAI SAN 2929_De nghi nhap TSBD 2899.docx
- Loại: docx | size: 27301 | lỗi: 
- Gợi ý placeholder:
  - `Dương Hiển Vang` → `{cn_ten_khach_hang}`
  - `2001-235488601` → `{cn_ma_khach_hang}`
- HĐ thấy: 2001-LCA-2025....., 2001-LCL-202501222

## DUONG HIEN VANG_TAI SAN 2929_Giay gioi thieu_Thanh.docx
- Loại: zip-not-word | size: 45568 | lỗi: Không có word/document.xml

## DUONG HIEN VANG_TAI SAN 2929_H_TC.docx
- Loại: legacy-doc | size: 755712 | lỗi: File is not a zip file

## DUONG HIEN VANG_TAI SAN 2929_S_ 28.MB.BB_G B_o c_o th_m __nh TSB_ l_ B_t __ng s_n.docx
- Loại: zip-not-word | size: 92672 | lỗi: Không có word/document.xml

## DUONG HIEN VANG_TAI SAN 2929_S_ 30.MB.BB_G Bi_n b_n x_c __nh gi_ tr_ TSB_ l_ QSD __t ok.docx
- Loại: zip-not-word | size: 59392 | lỗi: Không có word/document.xml

## DUONG HIEN VANG_TAI SAN 2929___u 1a Dang ky 2023.docx
- Loại: not-docx | size: 162 | lỗi: File is not a zip file

## DUONG HIEN VANG_TAI SAN 2929_mau 1a Dang ky 2023.docx
- Loại: docx | size: 33609 | lỗi: 
- Gợi ý placeholder:
  - `DƯƠNG HIỂN VANG` → `{cn_ten_khach_hang_in_hoa}`
  - `048077005294` → `{cn_so_cccd}`
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `048180003885` → `{cn_cccd_vo_chong}`
- CCCD thấy: 048077005294, 048180003885
- HĐ thấy: 2001-LCL-2025........, 2001-LCL-2025...............

## HSVV_1.2 PA SDV nhu cau doi song co TSB_.docx
- Loại: docx | size: 78351 | lỗi: 
- Gợi ý placeholder:
  - `DƯƠNG HIỂN VANG` → `{cn_ten_khach_hang_in_hoa}`
  - `048077005294` → `{cn_so_cccd}`
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `Hồ Trần Như Quỳnh` → `{cn_ten_vo_chong}`
  - `048180003885` → `{cn_cccd_vo_chong}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`
  - `Phòng giao dịch 2/9` → `{cn_phong_giao_dich}`
- CCCD thấy: 048077005294, 048180003885

## HSVV_24. MS 07. DXGN-CN BC DXGN kiem Giay nhan no 2023.docx
- Loại: docx | size: 101344 | lỗi: 
- Gợi ý placeholder:
  - `Dương Hiển Vang` → `{cn_ten_khach_hang}`
  - `048077005294` → `{cn_so_cccd}`
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `2001-235488601` → `{cn_ma_khach_hang}`
  - `Hồ Trần Như Quỳnh` → `{cn_ten_vo_chong}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`
  - `Phòng giao dịch 2/9` → `{cn_phong_giao_dich}`
- CCCD thấy: 048077005294
- HĐ thấy: 2001-LAV-2024................

## HSVV_26. MS 09.GXN-CN vay nhu cau doi song co huong luong.docx
- Loại: docx | size: 87697 | lỗi: 
- Gợi ý placeholder:
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `Hồ Trần Như Quỳnh` → `{cn_ten_vo_chong}`
  - `048180003885` → `{cn_cccd_vo_chong}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`

## HSVV_28. MS 11A.BBKT-CN BBKT tinh hinh su dung von vay tai Agribank noi cho vay.docx
- Loại: docx | size: 30179 | lỗi: 
- Gợi ý placeholder:
  - `Dương Hiển Vang` → `{cn_ten_khach_hang}`
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `2001-LAV-202401047` → `{cn_so_hop_dong_tin_dung}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`
- HĐ thấy: 2001-LAV-202401047, 2001-LDS-202402711

## HSVV_31. MS 12.BCTN-CN BC tinh hinh thu nhap.docx
- Loại: docx | size: 23337 | lỗi: 
- Gợi ý placeholder:
  - `Dương Hiển Vang` → `{cn_ten_khach_hang}`
  - `DƯƠNG HIỂN VANG` → `{cn_ten_khach_hang_in_hoa}`
  - `048077005294` → `{cn_so_cccd}`
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `Hồ Trần Như Quỳnh` → `{cn_ten_vo_chong}`
  - `048180003885` → `{cn_cccd_vo_chong}`
- CCCD thấy: 048077005294, 048180003885

## HSVV_7. MS 02A.BC_X-CN BCDXCV CN co TSBD.docx
- Loại: docx | size: 83629 | lỗi: 
- Gợi ý placeholder:
  - `Dương Hiển Vang` → `{cn_ten_khach_hang}`
  - `DƯƠNG HIỂN VANG` → `{cn_ten_khach_hang_in_hoa}`
  - `048077005294` → `{cn_so_cccd}`
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `K46/12 Nguyễn Thành Hãn` → `{cn_dia_chi}`
  - `Hồ Trần Như Quỳnh` → `{cn_ten_vo_chong}`
  - `048180003885` → `{cn_cccd_vo_chong}`
  - `24/07/2024` → `{cn_ngay_bao_cao}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`
  - `Phòng giao dịch 2/9` → `{cn_phong_giao_dich}`
- CCCD thấy: 048077005294, 048180003885

## HSVV_Ph_ l_c nh_n n_ 1 l_n.docx
- Loại: docx | size: 20447 | lỗi: 
- Gợi ý placeholder:
  - `28/06/2021` → `{cn_ngay_cap_cccd}`
  - `Cục CSQLHC` → `{cn_noi_cap_cccd}`
  - `Agribank Chi nhánh Nam Đà Nẵng` → `{cn_chi_nhanh}`
  - `Phòng giao dịch 2/9` → `{cn_phong_giao_dich}`
- CCCD thấy: 033065010986
- HĐ thấy: 2001-LAV-2024, 2001-LAV-2024...

## HSVV___ MS 02A.BC_X-CN BCDXCV CN co TSBD.docx
- Loại: not-docx | size: 162 | lỗi: File is not a zip file

## HSVV___2 PA SDV nhu cau doi song co TSB_.docx
- Loại: not-docx | size: 162 | lỗi: File is not a zip file
